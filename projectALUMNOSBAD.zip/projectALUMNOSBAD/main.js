document.addEventListener("DOMContentLoaded", () => {
    console.log("Proyecto inicializado");
});
